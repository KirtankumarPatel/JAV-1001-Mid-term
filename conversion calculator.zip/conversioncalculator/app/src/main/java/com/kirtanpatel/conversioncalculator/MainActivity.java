package com.kirtanpatel.conversioncalculator;

//Here we import the button, edit text, checkbox, textview...
import android.os.Bundle;

        import androidx.appcompat.app.AppCompatActivity;
        import android.view.View;
        import android.widget.Button;
        import android.widget.CheckBox;
        import android.widget.EditText;

        import android.widget.TextView;

//we create public class..
public class MainActivity extends AppCompatActivity {

    Button btnConvert;
    EditText etMiles,etFeets,etInches;
    TextView tvResult;
    CheckBox cbMetres;
    float result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etMiles=findViewById(R.id.etMiles);
        etFeets=findViewById(R.id.etFeets);
        etInches=findViewById(R.id.etInches);

        btnConvert=findViewById(R.id.btnConvert);
        tvResult=findViewById(R.id.tvResult);
        cbMetres=findViewById(R.id.cbMetres);

        btnConvert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                doConversion();
            }
        });
    }

//we create private void function and called if conditions
    private void doConversion()
    {

        result=0;
        if(!etInches.getText().toString().equals("")){
            result=result+(float)(Float.parseFloat(etInches.getText().toString().trim())*2.54);      //1 inch equals 2.54 cms
        }
        if(!etMiles.getText().toString().equals("")){
            result=result+(Float.parseFloat(etMiles.getText().toString().trim())*160934);      //1 mile equals 160934 cms
        }
        if(!etFeets.getText().toString().equals("")){
            result=result+(float)(Float.parseFloat(etFeets.getText().toString().trim())*30.48);      //1 feet equals 30.48 cms
        }


        if(cbMetres.isChecked()){
            result=result/100;
            tvResult.setText("Result:"+result+" metres");
        }else
        {
            tvResult.setText("Result:"+result+" cm");
        }

    }
}